Restaurant Review Application
This particukar application displays the review of the restaurant that is been marked on the map.And this application is said to be highly progressive responsive and accessible and also a necessary measures have been taken inorder to make this application available even at an offline mode by adding an extra javascript file called service worker file.Hence inorder to see all the features of this particular application it is required that it has to be launched on local/live server platform with port
number: 8000s
 